/*
 * Copyright (C) 2019 ~ 2019 Deepin Technology Co., Ltd.
 *
 * Author:     zccrs <zccrs@live.com>
 *
 * Maintainer: zccrs <zhangjide@deepin.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <DApplication>
#include <DMainWindow>
#include <DWidgetUtil>
#include <DListView>

DWIDGET_USE_NAMESPACE

int main(int argc, char *argv[])
{
    DApplication::loadDXcbPlugin();
    DApplication a(argc, argv);
    a.setAttribute(Qt::AA_UseHighDpiPixmaps);
    a.setOrganizationName("deepin");
    a.setApplicationName("dtk application");
    a.setApplicationVersion("1.0");
    a.setProductIcon(QIcon(":/images/logo.svg"));
    a.setProductName("Dtk Application");
    a.setApplicationDescription("This is a dtk template application.");

    DMainWindow w;
    DListView *view = new DListView(&w);
    QStandardItemModel *model = new QStandardItemModel(view);

    model->appendRow(new QStandardItem(QIcon::fromTheme("dcc_app_proxy"), "Action类型的图标"));
    model->appendRow(new QStandardItem(QIcon::fromTheme("dcc_nav_accounts"), "Icon类型的图标"));
    model->appendRow(new QStandardItem(QIcon::fromTheme("dcc_edit"), "Text类型的图标"));
    model->appendRow(new QStandardItem(QIcon::fromTheme("dcc_boot_menu"), "Dark主题的Action类型的图标"));
    model->appendRow(new QStandardItem(QIcon::fromTheme("dcc_nav_cloudsync"), "Dark主题的Icon类型的图标"));
    model->appendRow(new QStandardItem(QIcon::fromTheme("dcc_set_channel"), "Dark主题的Text类型的图标"));
    model->appendRow(new QStandardItem(QIcon::fromTheme("dcc_battery"), "Light主题的Action类型的图标"));
    model->appendRow(new QStandardItem(QIcon::fromTheme("dcc_nav_bluetooth"), "Light主题的Icon类型的图标"));
    model->appendRow(new QStandardItem(QIcon::fromTheme("dcc_rotate"), "Light主题的Text类型的图标"));

    view->setModel(model);
    w.setCentralWidget(view);
    w.setMinimumSize(500, 500);
    w.show();

    Dtk::Widget::moveToCenter(&w);

    return a.exec();
}
