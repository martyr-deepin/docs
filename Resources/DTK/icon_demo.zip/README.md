# 内置图标引擎

[toc]

## 前言

一般Qt应用开发中设置图标只需要知道`icon name`就可以使用, 图标引擎会自动去存放图标主题的目录下查找。一般主题目录下存放的够用，如果还是无法满足需求，可以使用内嵌资源，使用qt的资源系统。
内嵌资源也可以像使用主题中的图标一样，它是由插件buildinengine完成图标解析的，资源路径前缀为`："qrc:/icons/deepin/builtin/"`。

## 图标类型

根据以下划分方式，可以将图标按以下三种方式进行划分，这三种又可进行组合使用，达到特定场景下选择对应的Icon。

### 主题类型划分

根据图标所属的主题范围可分为三种，分别放在【light | dark | .】目录下进行区分。

- 亮色图标： 仅仅在亮色主题下才能使用。
- 暗色图标： 仅仅在暗色主题下才能使用。
- 通用图标： 在所有主题下都可以使用。

### 功能类型划分

根据图标功能可分为三类图标，分别放在【texts | actions | icons】目录下区分。

- 纯文本性图标（TextType），其颜色会跟随画笔的前景色变化（和文字颜色保持一致），针对一些工具性图标（一般都比较小，且颜色单一）。
- 动作型图标（ActionType），其颜色会在其 Mode 改变时跟随画笔前景色（Normal模式图标颜色不会发生变化），针对一些工具性图标（一般都比较小，且颜色单一）。
- 图标型图标（IconType），其颜色在任何模式下都不会变化，针对一些颜色丰富的图标。

### 引用图标数量划分

根据图标资源对应的图标引用的数量可分为两种，为【图标文件 | 图标目录/特定名称图标文件】进行区分。

- 单一图标： 一个QIcon资源只对应一个固定的图标，在任何情况下一个资源引用的是同一个图标。
- 状态图标： 一个QIcon资源对应的是多个图标的集合，在控件不同状态下会引用不同的图标进行绘制，icon对应四种模式，每种模式又有两种状态，组合起来共计可有八种图标，另外有一种为默认图标，所以一个状态图标资源最多可以引用九种图标。

## 图标命名规则

图标资源名称是按以下四个部分并以`_`连接组成的，这四个部分字母全部是小写，插件引擎正是按照这种命名规则进行解析所需要的参数，例如图标资源`dcc_dropdown_32px.svg`。

- 图标当前应用程序： 标识当前程序的前缀，控制中心的图标文件前缀`dcc`。
- 图标具体功能名称： 标识此图标的功能，`dropdown`。
- 图标尺寸： 标识此图标设计的默认大小，`32px`。
- 图标后缀： 标识此图标为何种格式，`.svg`。

### 单一图标

例如图标资源`dcc_dropdown_32px.svg`标标识为单一图标时，对应的图标文件即为`dcc_dropdown_32px.svg`。

### 状态图标

 当图标表示为状态图标时，满足上面图标资源命名规范外，还需满足下面要求。

- 图标资源做为目录
- 目录下存放一下几个真正的图标文件
  - normal.`图标后缀`： 默认图标，当其它状态的图标不存在时，图标引擎会使用此图标文件。
  - normal_on.`图标后缀`： 控件在QIcon::Normal模式下QIcon::On状态对应的图标文件。
  - normal_off.`图标后缀`： 控件在QIcon::Normal模式下QIcon::Off状态对应的图标文件。
  - active_on.`图标后缀`： 控件在QIcon::Active模式下QIcon::On状态对应的图标文件。
  - active_off.`图标后缀`： 控件在QIcon::Active模式下QIcon::On状态对应的图标文件。
  - selected_on.`图标后缀`： 控件在QIcon::Selected模式下QIcon::On状态对应的图标文件。
  - selected_off.`图标后缀`： 控件在QIcon::Selected模式下QIcon::On状态对应的图标文件。
  - disabled_on.`图标后缀`： 控件在QIcon::Disabled模式下QIcon::On状态对应的图标文件。
  - disabled_off.`图标后缀`： 控件在QIcon::Disabled模式下QIcon::Off状态对应的图标文件。

例如图标资源`dcc_dropdown_32px.svg`标识状态图标时，对应的图标文件的图标文件集合，所有图标文件为：

- `dcc_dropdown_32px.svg/normal.svg`
- `dcc_dropdown_32px.svg/normal_on.svg`
- `dcc_dropdown_32px.svg/normal_off.svg`
- `dcc_dropdown_32px.svg/active_on.svg`
- `dcc_dropdown_32px.svg/active_off.svg`
- `dcc_dropdown_32px.svg/selected_on.svg`
- `dcc_dropdown_32px.svg/selected_off.svg`
- `dcc_dropdown_32px.svg/disabled_on.svg`
- `dcc_dropdown_32px.svg/disabled_off.svg`

当只关心`图标模式`而不关心状态时，`图标文件`可以只用`图标模式.图标后缀`为文件名。例如当图标为active模式时，若不存在`dcc_dropdown_32px.svg/active_on.svg`和`dcc_dropdown_32px.svg/active_off.svg`图标文件，内置图标引擎会尝试绘制`dcc_dropdown_32px.svg/active.svg`。

### 图标背景

含有`图标资源`同名后缀.background文件，则会在使用图标资源的时候，先绘制.background，再绘制图标资源指定的图标文件。

例如含有`dcc_dropdown_32px.svg.background`文件时，则会先绘制`dcc_dropdown_32px.svg.background`，再绘制图标资源指定的图标文件。

## 图标使用

以下以`亮色主题`下`动作型图标`的`状态图标`(`dcc_app_proxy_dir`)为例，介绍如何使用内置主题图标。

### 图标文件位置

- 获取图标文件，并按照`图标命名规则`规范图标文件名称。
- 将图标文件按使用场景放置在指定目录。

图标文件位于 `【light | dark | .】/【texts | actions | icons】/【图标文件 | 图标目录/特定名称图标文件】`，所以放置在 `light/actions/ddc_app_proxy_dir_32px.svg`目录下，
图标资源`dcc_app_proxy_dir`对应的所有图标文件应位于以下位置。

- `./light/actions/ddc_app_proxy_dir_32px.svg/normal.svg`
- `./light/actions/ddc_app_proxy_dir_32px.svg/normal_on.svg`
- `./light/actions/ddc_app_proxy_dir_32px.svg/normal_off.svg`
- `./light/actions/ddc_app_proxy_dir_32px.svg/active_on.svg`
- `./light/actions/ddc_app_proxy_dir_32px.svg/active_off.svg`
- `./light/actions/ddc_app_proxy_dir_32px.svg/selected_on.svg`
- `./light/actions/ddc_app_proxy_dir_32px.svg/selected_off.svg`
- `./light/actions/ddc_app_proxy_dir_32px.svg/disabled_on.svg`
- `./light/actions/ddc_app_proxy_dir_32px.svg/disabled_off.svg`

若需要先绘制背景图片，则可添加图标文件`./light/actions/ddc_app_proxy_dir_32px.svg.background`。

### 添加XXX.qrc文件引用

在qrc文件里添加对以上图标文件的引用，它会将图标文件以资源的形式编译到库中。

``` xml
<RCC>
    <qresource prefix="/icons/deepin/builtin/light">
        <file>actions/dcc_app_proxy_dir_32px.svg/normal.svg</file>
        <file>actions/dcc_app_proxy_dir_32px.svg/normal_on.svg</file>
        <file>actions/dcc_app_proxy_dir_32px.svg/normal_off.svg</file>
        <file>actions/dcc_app_proxy_dir_32px.svg/active_on.svg</file>
        <file>actions/dcc_app_proxy_dir_32px.svg/active_off.svg</file>
        <file>actions/dcc_app_proxy_dir_32px.svg/selected_on.svg</file>
        <file>actions/dcc_app_proxy_dir_32px.svg/selected_off.svg</file>
        <file>actions/dcc_app_proxy_dir_32px.svg/disabled_on.svg</file>
        <file>actions/dcc_app_proxy_dir_32px.svg/disabled_off.svg</file>
    </qresource>
</RCC>
```

### 程序使用

 在代码中只需要以下方式就能使用`dcc_app_proxy_dir`对应的图标资源了，内置图标引擎会自动寻找到指定的图标，并在状态改变时选择正确的图标进行绘制。

``` c++
const QIcon &icon = QIcon::fromTheme("dcc_app_proxy_dir")；
```

### 运行环境

内置图标引擎位于qt5integration/builtinengine项目中，安装qt5integration及其所需依赖即可。

``` sh
sudo apt install dde-qt5integration
```

## 参考文档

- [Qt样式控制：主题切换以及QIcon的源码探析](https://blog.csdn.net/Alezan/article/details/108221723)
- `builtinengine`解析规则： 项目位于`qt5integration/iconengineplugins/builtinengine`
- `qt5integration`控件状态到Icon状态映射: 项目位于`qt5integration/styleplugins/chameleon`
- [DTK 教程](https://github.com/linuxdeepin/qt5integration/wiki)