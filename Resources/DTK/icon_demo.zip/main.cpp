/*
 * Copyright (C) 2019 ~ 2019 Deepin Technology Co., Ltd.
 *
 * Author:     zccrs <zccrs@live.com>
 *
 * Maintainer: zccrs <zhangjide@deepin.com>
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include <DApplication>
#include <DMainWindow>
#include <DWidgetUtil>
#include <DListView>
#include <QGridLayout>
#include <QCheckBox>
#include <QPushButton>
#include <QListWidget>
#include <QHBoxLayout>
#include <QScreen>
#include <QLabel>
#include <QRadioButton>
#include <QToolButton>
#include <QFileInfo>
#include <QDir>
#include <QFormLayout>
#include <QLineEdit>

#include <DGuiApplicationHelper>
#include <DIconButton>
#include <DButtonBox>
#include <QGroupBox>

DWIDGET_USE_NAMESPACE

/**
 * @brief The BuildinIconEngineExample class
 * 展示内置图标引擎的功能
 * 按主题图标、状态图标、类型图标、背景图标进行展示
 */
class BuildinIconEngineExample {
public:
    BuildinIconEngineExample(QWidget *parent)
        : m_container(new QWidget(parent))
    {
        init();
    }

    // 控件容器
    QWidget* container()
    {
        return m_container;
    }

private:
    void init()
    {

        auto layout = new QVBoxLayout(m_container);

        layout->setDirection(QBoxLayout::TopToBottom);
        layout->setSpacing(20);

        layout->addWidget(themeIcon());
        layout->addWidget(statusIcon());
        layout->addWidget(typeIcon());
        layout->addWidget(backgroundIcon());
    }

    // 主题图标
    QWidget* themeIcon()
    {
        auto view = new QGroupBox("主题图标，切换系统主题或应用主题会显示不同的图标");
        auto layout = new QVBoxLayout(view);

        auto legend = createIconLegend({
                                           {"dark/actions/test_follow_theme_32px.svg", "dark"},
                                           {"light/actions/test_follow_theme_32px.svg", "light"},
                                           {"actions/test_all_theme_32px.svg", "all-theme"}
                                       });
        layout->addWidget(legend);

        auto hlayout = new QHBoxLayout();
        hlayout->setSpacing(20);

        hlayout->addWidget(createButtons("test_follow_theme", "跟随主题"), 0, Qt::AlignLeft);
        hlayout->addWidget(createButtons("test_all_theme", "通用型主题"), 0, Qt::AlignLeft);

        createIconDescriptionByLegend(legend, hlayout);

        hlayout->addItem(new QSpacerItem(0, 0, QSizePolicy::Expanding));
        layout->addLayout(hlayout);

        return view;
    }

    // 状态图标
    QWidget* statusIcon()
    {
        auto view = new QGroupBox("状态图标，改变控件状态会显示不同的图标");
        auto layout = new QVBoxLayout(view);
        auto legend = createIconLegend({
                                           {"icons/test_status_32px.svg/active.svg", "active"},
                                           {"icons/test_status_32px.svg/selected.svg", "selected"},
                                           {"icons/test_status_32px.svg/disabled.svg", "disabled"},
                                           {"icons/test_status_32px.svg/normal.svg", "normal"},
                                       });
        layout->addWidget(legend);

        auto hlayout = new QHBoxLayout();
        hlayout->setSpacing(20);

        hlayout->addWidget(createButtons("test_status", "非Disabled状态"), 0, Qt::AlignLeft);
        hlayout->addWidget(createButtons("test_status", "Disabled状态", true), 0, Qt::AlignLeft);

        createIconDescriptionByLegend(legend, hlayout);

        hlayout->addItem(new QSpacerItem(0, 0, QSizePolicy::Expanding));
        layout->addLayout(hlayout);

        return view;

    }

    // 类型图标
    QWidget* typeIcon()
    {
        auto view = new QGroupBox("类型图标，比较动作型图标、图标型图标、纯文本性图标显示的区别");

        auto layout = new QVBoxLayout(view);
        auto legend = createIconLegend({
                                           {"actions/test_action_32px.svg", "action"},
                                           {"icons/test_icon_32px.svg", "icon"},
                                           {"texts/test_text_32px.svg", "text"}
                                       });
        layout->addWidget(legend);

        auto hlayout = new QHBoxLayout();
        hlayout->setSpacing(20);


        hlayout->addWidget(createButtons("test_action", "动作型图标"), 0, Qt::AlignLeft);
        hlayout->addWidget(createButtons("test_icon", "图标性图标"), 0, Qt::AlignLeft);
        hlayout->addWidget(createButtons("test_text", "纯文本型图标"), 0, Qt::AlignLeft);

        createIconDescriptionByLegend(legend, hlayout);

        hlayout->addItem(new QSpacerItem(0, 0, QSizePolicy::Expanding));
        layout->addLayout(hlayout);

        return view;
    }

    // 背景图标
    QWidget* backgroundIcon()
    {
        auto view = new QGroupBox("背景图标，比较使用背景图标和不使用背景图标之间的区别");
        auto layout = new QVBoxLayout(view);

        auto hlayout = new QHBoxLayout();
        hlayout->setSpacing(20);


        auto legend = createIconLegend({
                                           {"actions/test_background_32px.svg", "前景图标"},
                                           {"actions/test_background_32px.svg.background", "背景图片"},
                                           {"actions/test_nobackground_32px.svg", "不存在背景的图标"},
                                       });
        layout->addWidget(legend);

        hlayout->addWidget(createButtons("test_background", "存在背景"), 0, Qt::AlignLeft);
        hlayout->addWidget(createButtons("test_nobackground", "不存在背景"), 0, Qt::AlignLeft);

        createIconDescriptionByLegend(legend, hlayout);

        hlayout->addItem(new QSpacerItem(0, 0, QSizePolicy::Expanding));
        layout->addLayout(hlayout);

        return view;
    }

private:
    // icon描述信息
    QWidget* createIconDescription(const QString &path)
    {
        QString filePath = path;
        auto view = new QWidget();
        auto desc = new QFormLayout(view);
        desc->addRow(new QLabel("资源路径："), new QLabel(filePath));
        {
            auto control = new QLabel(iconName(filePath));
            control->setTextInteractionFlags(Qt::TextSelectableByMouse);
            desc->addRow(new QLabel("图标名称："), control);
        }

        desc->addRow(new QLabel("尺寸："), new QLabel(iconSize(filePath)));
        desc->addRow(new QLabel("主题："), new QLabel(iconTheme(filePath)));
        desc->addRow(new QLabel("图标类型："), new QLabel(iconType(filePath)));

        return view;
    }

    // 根据所选图例来创建描述信息，并插入到第一项
    void createIconDescriptionByLegend(QListWidget* legend, QBoxLayout* hlayout)
    {
        QObject::connect(legend, &QListWidget::currentItemChanged, [this, hlayout](QListWidgetItem *current, QListWidgetItem */*previous*/){
            if (!current || hlayout->count() <= 0) {
                return;
            }

            const auto &filePath = current->data(QListWidgetItem::UserType + 1).toString();
            auto description = createIconDescription(filePath);
            // 判断是否已存在，若存在则需要先删除。
            if (auto widget = hlayout->itemAt(0)->widget()->property("_isExist").isValid()) {
                auto item = hlayout->takeAt(0);
                delete item->widget();
            }

            description->setProperty("_isExist", 1);
            hlayout->insertWidget(0, description);
        });
        legend->setCurrentRow(0);
    }

    // 创建使用QIcon的控件
    QWidget* createButtons(const QString &fileName, const QString &desc = QString(), bool disable = false)
    {
        auto view = new QWidget();
        view->setFixedWidth(200);
        view->setSizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        auto layout = new QFormLayout(view);
        if (!desc.isEmpty()) {
            auto label = new QLabel(desc);
            label->setAlignment(Qt::AlignCenter);
            layout->addWidget(label);
        }
        layout->addWidget(generateAbstractButton<QPushButton>(fileName, disable));
        layout->addWidget(generateAbstractButton<QCheckBox>(fileName, disable));
        {
            auto control = new DIconButton(nullptr);
            control->setIcon(QIcon::fromTheme(fileName));
            control->setDisabled(disable);
            layout->addWidget(control);
        }
        {
            auto control = new DButtonBoxButton("DButtonBoxButton");
            control->setIcon(QIcon::fromTheme(fileName));
            control->setDisabled(disable);
            layout->addWidget(control);
        }

        return view;
    }

    // 创建图例，不同状态对应的图标
    using IconLegendItem = QPair<QString, QString>;
    QListWidget* createIconLegend(const QList<IconLegendItem> &iconLegends)
    {
        auto iconLegend = new QListWidget();
        iconLegend->setFlow(QListView::LeftToRight);
        iconLegend->setFixedHeight(30);

        for (auto item : iconLegends) {
            QString filePath = iconPath(item.first);
            auto widgetItem = new QListWidgetItem(QIcon(filePath), item.second);
            widgetItem->setData(QListWidgetItem::UserType + 1, filePath);
            iconLegend->addItem(widgetItem);
        }

        return iconLegend;
    }

    QString iconPath(const QString &filePath)
    {
        const char* qrcPrefix = ":/icons/deepin/builtin";
        return QString("%1/%2").arg(qrcPrefix).arg(filePath);
    }

    // icon size解析规则
    QString iconSize(const QString& filePath)
    {
        return filePath.left(filePath.lastIndexOf("px.")).mid(filePath.lastIndexOf("_") + 1);
    }

    // icon type解析规则
    QString iconType(const QString& filePath)
    {
        if (filePath.endsWith(".background")) {
            return "背景图片";
        }
        if (filePath.contains("/actions/"))
            return "动作型图标";
        if (filePath.count("/icons/") > 1)
            return "图标型图标";
        if (filePath.contains("/texts/"))
            return "纯文本性图标";

        return "not-buildin-type";
    }

    // icon name解析规则
    QString iconName(const QString& filePath)
    {
        QFileInfo fileInfo(filePath);
        const QString& fileName = fileInfo.fileName();
        const QList<QString> modeKeys{
            "active",
            "selected",
            "disabled",
            "normal",
        };
        for (auto item : modeKeys) {
            if (fileName.startsWith(item)) {
                // 状态图标，需要获取到图标资源路径，再进行icon name解析。
                return iconName(fileInfo.absolutePath());
            }
        }

        if (fileName.endsWith(".background")) {
            return "配合其它图标使用，不单独使用";
        }


        return fileName.left(fileName.lastIndexOf("_"));
    }

    // icon theme解析规则
    QString iconTheme(const QString& filePath)
    {
        if (filePath.contains("dark"))
            return "暗色";
        if (filePath.contains("light"))
            return "亮色";

        return "通用";
    }

    template<class T>
    QWidget* generateAbstractButton(const QString &fileName, bool disable)
    {
        auto control = new T(nullptr);
        control->setIcon(QIcon::fromTheme(fileName));
        control->setText(control->metaObject()->className());
        control->setDisabled(disable);

        return control;
    }

private:
    QWidget* m_container;
};

int main(int argc, char *argv[])
{
    DApplication::loadDXcbPlugin();
    DApplication a(argc, argv);
    a.setAttribute(Qt::AA_UseHighDpiPixmaps);
    a.setOrganizationName("deepin");
    a.setApplicationName("dtk application");
    a.setApplicationVersion("1.0");
    a.setProductIcon(QIcon(":/images/logo.svg"));
    a.setProductName("Dtk Application");
    a.setApplicationDescription("This is a dtk template application.");

    DMainWindow w;
    w.setMinimumHeight(qApp->primaryScreen()->availableSize().height() / 10 * 9);

    BuildinIconEngineExample manager(&w);

    w.setCentralWidget(manager.container());
    w.show();

    Dtk::Widget::moveToCenter(&w);

    return a.exec();
}
